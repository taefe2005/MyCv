from django.shortcuts import render

from .models import profile
# Create your views here.

def base(request):
    name_l = profile.objects.get(id=1)
    namelist = {
        'prof' : name_l
    }
    return render(request,'myapp/base.html',namelist)