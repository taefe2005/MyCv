from django.db import models

# Create your models here.

class profile(models.Model):
    name=models.CharField(max_length=90)
    email=models.EmailField()
    phone=models.CharField(max_length=90)
    summary=models.TextField()
    skills=models.TextField()
    expereince=models.TextField()
    education=models.TextField()

    def __str__(self):
        return f"{self.name}"